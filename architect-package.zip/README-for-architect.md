# YowareTemplate Phase 1 — 架構師審核文件包

> 本文件包供網絡/系統架構師審核 YowareTemplate Phase 1 MVP 的架構設計。

## 文件清單

| 文件 | 用途 | 閱讀順序 |
|---|---|---|
| `SAD.md` | 系統架構與設計（System Architecture & Design） | 1（核心） |
| `PRD.md` | 產品需求文件，說明功能範圍與使用者流程 | 2（背景） |
| `phase1-api-contract.md` | API 規格與 D1 Schema 詳細契約 | 3（介面） |
| `01-setup-guide.md` | 部署與環境設定步驟 | 4（實現參考） |

## 審核重點

請特別確認 `SAD.md` 第 1.1 節「架構決策確認」中的以下決策：

1. **統一內建模板**：所有模板皆為平台內建 Template Package，廢棄外部獨立部署方案。
2. **Template Registry**：採用「動態 import + 靜態映射表」混合實作。
3. **內容儲存策略**：Phase 1 沿用 `public/data/content-{slug}.json`，未來再考慮遷移至 D1。
4. **AI Worker 內容格式**：短期直接產出模板專屬 JSON，長期建立通用內容中間層。
5. **路由命名**：`/pre/:slug`（預覽）與 `/man/:slug`（後台編輯）。
6. **AI Worker `/api/generate` 認證**：使用內部 `AI_WORKER_SECRET`。
7. **客戶網站部署**：獨立 repo + 獨立 Cloudflare Pages 專案。
8. **付款觸發方式**：Phase 1 由經營者在 `/platform-admin` 手動確認付款後觸發自動開站。

## 關鍵流程

```text
客戶瀏覽模板 → 填寫表單 → AI 生成預覽 → 輸入域名/微調 → 提交訂單
                                                        ↓
經營者 /platform-admin ← WhatsApp 通知 ← 平台 API Worker
        ↓
   審核 / 復現預覽 / 標記付款
        ↓
   一鍵開站 → Admin API Worker Orchestrator
        ↓
   GitHub repo → brief/content → Pages project → domain → 交付
```

## 技術堆疊

- 前端：React 18 + TypeScript + Vite 7 + Tailwind CSS 3
- 後端：Cloudflare Workers（Platform API / Admin API / AI Content）
- 資料庫：Cloudflare D1
- 儲存：Cloudflare R2
- 部署：Cloudflare Pages（平台前台）+ GitHub（客戶網站 repo）
- AI：DeepSeek + Pixabay

## 產出物

- 本文件包內含 Markdown 文件，可直接審閱或轉換為 PDF/簡報。
- 原始檔案位於專案 `docs/` 目錄，隨專案版本控制同步更新。

---

*文件包建立時間：2026-07-17*
*適用版本：YowareTemplate Phase 1 MVP*
